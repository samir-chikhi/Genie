# Dossier Images

Placez ici toutes vos images pour le site :

## Images recommandées

1. **Logo du Génie** (format PNG transparent)
   - Nom suggéré : `logo-genie.png`
   - Dimensions : 500x500px minimum

2. **Photos de l'espace**
   - Photos de l'espace coworking
   - Photos des salles de réunion
   - Photos de l'espace détente
   - Dimensions : 1920x1080px ou 16:9

3. **Photos d'événements**
   - Ateliers
   - Networking
   - Conférences

4. **Favicon**
   - Nom : `favicon.ico`
   - Dimensions : 32x32px et 16x16px

## Optimisation

Avant d'ajouter vos images :
- Compressez-les (utilisez TinyPNG.com ou Squoosh.app)
- Format recommandé : JPEG pour photos, PNG pour logos
- Poids maximum : 500KB par image

## Nommage

Utilisez des noms descriptifs :
- ✅ `espace-coworking-principal.jpg`
- ✅ `salle-reunion-1.jpg`
- ❌ `IMG_1234.jpg`
- ❌ `photo.jpg`
